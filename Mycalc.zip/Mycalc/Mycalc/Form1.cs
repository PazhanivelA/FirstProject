﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mycalc
{
    public partial class MyCalc : Form
    {
        public MyCalc()
        {
            InitializeComponent();
        }

        private void BtnResult_Click(object sender, EventArgs e)
        {
            try
            {
                int ValueOne = Convert.ToInt32(TxtOne.Text);
                int ValueSecond = Convert.ToInt32(TxtSecond.Text);
                if (TxtOne.Text == "" || TxtSecond.Text == "")
                {
                    MessageBox.Show("Please Enter a number in given boxes");
                }
                else if (RbtnSum.Checked)
                {
                    int Result = ValueOne + ValueSecond;
                    TxtResult.Visible = true;
                    TxtResult.Text = Convert.ToString(Result);
                }
                else if (RbtnSubract.Checked)
                {
                    int Result = ValueOne - ValueSecond;
                    TxtResult.Visible = true;
                    TxtResult.Text = Convert.ToString(Result);
                }
                else if (RbtnMultiply.Checked)
                {
                    int Result = ValueOne * ValueSecond;
                    TxtResult.Visible = true;
                    TxtResult.Text = Convert.ToString(Result);
                }
                else if (RbtnDivide.Checked)
                {
                    if (ValueOne == 0 || ValueSecond == 0)
                    {
                        MessageBox.Show("Please Enter Non-Zero Vaule");
                        TxtOne.Text = "";
                        TxtSecond.Text = "";
                    }
                    else
                    {
                        int Result = ValueOne - ValueSecond;
                        TxtResult.Visible = true;
                        TxtResult.Text = Convert.ToString(Result);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Please Enter Numbers Only");
                TxtOne.Text = "";
                TxtSecond.Text = "";
            }
            finally
            {
                TxtOne.Text = "";
                TxtSecond.Text = "";
            }
        }
    }
}